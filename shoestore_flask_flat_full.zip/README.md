
# ShoeLab – Simple Shoe Store (Flask)

See README in previous message for full instructions.
