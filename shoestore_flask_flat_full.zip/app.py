
import os, json
from flask import Flask, render_template, request, session, redirect, url_for, flash, jsonify

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-key")
DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "products.json")

def load_products():
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def get_cart():
    if "cart" not in session:
        session["cart"] = {}
    return session["cart"]

def cart_items_details(cart, products):
    items = []
    total = 0
    for pid, entry in cart.items():
        p = next((x for x in products if x["id"] == int(pid)), None)
        if not p: 
            continue
        qty = max(1, int(entry.get("qty", 1)))
        size = entry.get("size")
        line = p["price"] * qty
        total += line
        items.append({"product": p, "qty": qty, "size": size, "line_total": line})
    return items, total

@app.route("/")
def home():
    return redirect(url_for("products_page"))

@app.route("/products")
def products_page():
    products = load_products()
    q = request.args.get("q", "").strip().lower()
    brand = request.args.get("brand", "").strip()
    category = request.args.get("category", "").strip()
    min_price = int(request.args.get("min_price", "0") or 0)
    max_price = int(request.args.get("max_price", "999999") or 999999)
    size = request.args.get("size", "").strip()

    filtered = []
    for p in products:
        if q and q not in (p["name"] + " " + p["brand"] + " " + p["category"]).lower():
            continue
        if brand and p["brand"] != brand:
            continue
        if category and p["category"] != category:
            continue
        if not (min_price <= p["price"] <= max_price):
            continue
        if size and int(size) not in p["sizes"]:
            continue
        filtered.append(p)

    brands = sorted({p["brand"] for p in products})
    categories = sorted({p["category"] for p in products})
    sizes = sorted({s for p in products for s in p["sizes"]})
    return render_template("products.html", products=filtered, brands=brands, categories=categories, sizes=sizes, q=q, brand=brand, category=category, min_price=min_price, max_price=max_price, size=size)

@app.route("/product/<int:pid>")
def product_detail(pid):
    products = load_products()
    p = next((x for x in products if x["id"] == pid), None)
    if not p:
        flash("Product not found.", "error")
        return redirect(url_for("products_page"))
    return render_template("product_detail.html", p=p)

@app.route("/cart")
def cart_page():
    products = load_products()
    cart = get_cart()
    items, total = cart_items_details(cart, products)
    return render_template("cart.html", items=items, total=total)

@app.route("/cart/add", methods=["POST"])
def cart_add():
    pid = request.form.get("pid")
    size = request.form.get("size")
    qty = int(request.form.get("qty", "1"))
    if not pid or not size:
        flash("Choose size and quantity.", "error")
        return redirect(url_for("products_page"))
    cart = get_cart()
    entry = cart.get(pid, {"qty": 0, "size": int(size)})
    entry["qty"] = int(entry.get("qty", 0)) + max(1, qty)
    entry["size"] = int(size)
    cart[pid] = entry
    session.modified = True
    flash("Added to cart.", "ok")
    return redirect(url_for("cart_page"))

@app.route("/cart/update", methods=["POST"])
def cart_update():
    cart = get_cart()
    for key, val in request.form.items():
        if key.startswith("qty_"):
            pid = key.split("_",1)[1]
            try:
                qty = max(0, int(val))
            except:
                qty = 1
            if qty == 0:
                cart.pop(pid, None)
            else:
                if pid in cart:
                    cart[pid]["qty"] = qty
    session.modified = True
    flash("Cart updated.", "ok")
    return redirect(url_for("cart_page"))

@app.route("/checkout", methods=["GET", "POST"])
def checkout():
    products = load_products()
    cart = get_cart()
    items, total = cart_items_details(cart, products)
    if request.method == "POST":
        name = request.form.get("name","").strip()
        email = request.form.get("email","").strip()
        address = request.form.get("address","").strip()
        if not (name and email and address and items):
            flash("Please complete all fields and have items in your cart.", "error")
            return render_template("checkout.html", items=items, total=total)
        order = {"name": name, "email": email, "address": address, "total": total, "items": [{"id": it["product"]["id"], "qty": it["qty"], "size": it["size"]} for it in items]}
        session["cart"] = {}
        flash("Order placed! (demo only, no payment processed)", "ok")
        return render_template("order_success.html", order=order)
    return render_template("checkout.html", items=items, total=total)

@app.route("/api/products")
def api_products():
    return jsonify(load_products())

@app.route("/health")
def health():
    return {"ok": True}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=True)
